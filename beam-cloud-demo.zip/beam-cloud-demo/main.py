# ===========================================================
# IMPORT REQUIRED MODULES
# ===========================================================

import os
import time
from typing import Any, Dict, List, Optional

from openai import OpenAI
from transformers import AutoTokenizer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.progress import Progress
from rich.live import Live



# ===========================================================
# DEFINE CHAT APPLICATION CLASS
# ===========================================================

class ChatApplication:
    def __init__(self, client: OpenAI, model: str):
        """Initialize ChatApplication with OpenAI client and selected model."""
        self.client = client
        self.model = model
        self.conversation_history: List[Dict[str, Any]] = []

    def process_user_input(
        self, user_input: str, img_link: Optional[str] = None, stream: bool = False
    ) -> str:
        """Process user input and return assistant's response."""
        
        # Handle image-based queries for vision models
        if self.model == "OpenGVLab/InternVL2_5-8B" and img_link:
            self.conversation_history.append(
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_input},
                        {"type": "image_url", "image_url": {"url": img_link}},
                    ],
                }
            )
        else:
            # Store user input in conversation history
            self.conversation_history.append({"role": "user", "content": user_input})

        # Call OpenAI API to generate a response
        response = self.client.chat.completions.create(
            model=self.model,
            messages=self.conversation_history,
            stream=stream,
        )

        # Handle streaming mode
        if stream:
            print("Assistant: ", end="", flush=True)
            full_response = ""
            for chunk in response:
                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    full_response += content
            print()
            self.conversation_history.append(
                {"role": "assistant", "content": full_response}
            )
            return full_response

        else:
            # Handle non-streaming response
            assistant_message = response.choices[0].message
            final_response = assistant_message.content
            self.conversation_history.append(
                {"role": "assistant", "content": final_response}
            )
            return final_response





# ===========================================================
# INITIALIZE CLI AND CHAT FUNCTION
# ===========================================================

console = Console()

def chat() -> None:
    """Main chat loop for interactive conversation."""
    
    # Display welcome message
    console.print(
        Panel("[bold cyan]Welcome to the CLI Chat Application![/bold cyan]", expand=False)
    )
    console.print("[bold white]Type 'quit' to exit the conversation.[/bold white]")

    # Setup OpenAI API credentials
    app_url = Prompt.ask("[bold yellow]Enter the app URL[/bold yellow]")
    beam_config = open(f"{os.path.expanduser('~')}/.beam/config.ini").read().split("\n")
    
    # Validate API token
    if len(beam_config) < 2:
        console.print("[bold red]Error:[/bold red] Beam config does not contain a token.", style="red")
        return
    beam_token = beam_config[1].split(" = ")[1].strip()

    # Ask user for streaming mode preference
    stream = Prompt.ask("[bold yellow]Stream mode? (y/n)[/bold yellow]").lower() == "y"

    # Initialize OpenAI client
    client = OpenAI(
        api_key=beam_token,
        base_url=f"{app_url}/v1",
    )

    # Fetch available models and select the first one
    models = client.models.list()
    model = models.data[0].id
    console.print(Panel(f"✅ [bold green]Model {model} is ready[/bold green]"))

    # Create chat application instance
    chat_app = ChatApplication(client, model)

    # ===========================================================
    # MAIN INTERACTIVE CHAT LOOP
    # ===========================================================

    try:
        while True:
            console.print("\n" + "-" * 50, style="dim")
            user_input = Prompt.ask("[bold blue]Question[/bold blue]")
            
            # Exit condition
            if user_input.lower() == "quit":
                console.print("[bold magenta]Goodbye! 👋[/bold magenta]")
                break

            # Handle vision model image input
            img_link = None
            if model == "OpenGVLab/InternVL2_5-8B":
                img_link = Prompt.ask("[bold yellow]Image link (press enter to skip)[/bold yellow]")

            chat_app.conversation_history.append({"role": "user", "content": user_input})

            # Start response timer
            start_time = time.time()

            # ===========================================================
            # STREAMING MODE
            # ===========================================================

            if stream:
                full_response = ""
                try:
                    with Live(
                        Panel("⏳ [bold cyan]Thinking...[/bold cyan]", title="Assistant", expand=False, style="cyan"),
                        console=console,
                        refresh_per_second=10,
                    ) as live:
                        response = chat_app.client.chat.completions.create(
                            model=chat_app.model,
                            messages=chat_app.conversation_history,
                            stream=True,
                        )

                        for chunk in response:
                            if hasattr(chunk.choices[0].delta, "content"):
                                content = chunk.choices[0].delta.content
                                if content:
                                    full_response += content
                                    live.update(
                                        Panel(full_response, title="Assistant", expand=False, style="cyan")
                                    )

                    chat_app.conversation_history.append({"role": "assistant", "content": full_response})

                except Exception as e:
                    console.print(f"[bold red]Error during streaming:[/bold red] {e}")

            # ===========================================================
            # NON-STREAMING MODE
            # ===========================================================

            else:
                try:
                    with Progress() as progress:
                        task = progress.add_task("[cyan]Generating response...", total=100)
                        response = chat_app.process_user_input(user_input, img_link, stream)
                        progress.update(task, advance=100)

                    chat_app.conversation_history.append({"role": "assistant", "content": response})

                    console.print("\n✨ [bold green]Final Response:[/bold green] ✨")
                    console.print(Panel(response, title="Assistant", expand=False, style="cyan"))

                except Exception as e:
                    console.print(f"[bold red]Error during response generation:[/bold red] {e}")

            # ===========================================================
            # PERFORMANCE METRICS
            # ===========================================================

            # Measure output token count and processing time
            tokenizer = AutoTokenizer.from_pretrained(model)
            output_tokens = len(tokenizer.encode(full_response if stream else response))

            end_time = time.time()
            total_time = end_time - start_time
            output_tokens_per_second = output_tokens / total_time if total_time > 0 else 0

            console.print(f"📜 [bold yellow]Tokens Generated:[/bold yellow] {output_tokens}")
            console.print(f"⏳ [bold yellow]Time Taken:[/bold yellow] {total_time:.2f}s")
            console.print(f"⚡ [bold yellow]Tokens Per Second:[/bold yellow] {output_tokens_per_second:.2f}")

    except KeyboardInterrupt:
        console.print("\n[bold red]Exiting the chat.[/bold red]")


# ===========================================================
# EXECUTE THE CHAT FUNCTION IF RUN AS MAIN
# ===========================================================

if __name__ == "__main__":
    chat()