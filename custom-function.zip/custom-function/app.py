import os 
import requests  
from beam import endpoint

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_API_KEY = "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"


SYSTEM_PROMPT = (
    "You are a professional translation engine. "
    "Translate the user's text into the requested target language (ISO code). "
    "Return ONLY the translated text with no extra commentary. "
    "Preserve meaning, tone, formatting, and named entities. Keep code unchanged."
)



@endpoint(
    name="translate",
    cpu=1.0,
    memory=512,
)
def translate(**input):
    text = input.get("text", "")
    target_language = input.get("target_language", "fr")
    source_language = input.get("source_language") 

    if not GROQ_API_KEY:
        return {"error": "Missing GROQ_API_KEY environment variable"}
    if not text:
        return {"error": "Missing 'text' input"}
    if not target_language:
        return {"error": "Missing 'target_lang' input"}
    

    user_prompt = (
        f"Target language: {target_language}\n"
        + (f"Source language (hint): {source_language}\n" if source_language else "")
        + "Text to translate:\n<<<\n"
        f"{text}\n>>>"
    )

    payload = {
        "model": "deepseek-r1-distill-llama-70b",
        "temperature": 0,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    }

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }


    try:
        r = requests.post(GROQ_API_URL, headers=headers, json=payload, timeout=30)
        r.raise_for_status()
        data = r.json()
        translated = data["choices"][0]["message"]["content"].strip()
        return {"result": translated}
    except requests.HTTPError as e:
        body = e.response.text
        return {"error": f"Groq HTTP {e.response.status_code}: {body[:500]}"}  # trimmed
    except Exception as e:
        return {"error": f"Groq call failed: {type(e).__name__}: {e}"}



