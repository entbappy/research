import requests

# Your deployed Beam endpoint URL
url = "https://translate-9f37a2a-v5.app.beam.cloud"

headers = {
    "Connection": "keep-alive",
    "Content-Type": "application/json",
    # Beam auth (keep it secret). This is separate from GROQ_API_KEY,
    # which must be set on the server side env.
    "Authorization": "Bearer udZpfSqoXrH6OcIWhde_85NYCbIr3IfM6jGq6HO8KhzUpMiDEDPp0Qmw29zWAYyuYDNkUyJoNgNXqxhBQ2N3Kw==",
}

data = {
    "text": "Hello, how are you?",
    "target_lang": "fr",
    "source_lang": "en"
}

resp = requests.post(url, headers=headers, json=data, timeout=60)
print(resp.status_code, resp.json())
