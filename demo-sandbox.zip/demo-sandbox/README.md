conda create -n llmapp python=3.11 -y

conda activate llmapp 

pip install -r requirements.txt




beam secret create OPENAI_API_KEY sk-***********






CHAT_URL="https://053e5787-21a3-4df7-af49-2e3000a1e332-8000.app.beam.cloud"

curl -s -X POST "$CHAT_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [
      {"role":"system","content":"You are a helpful assistant."},
      {"role":"user","content":"what is python?"}
    ]
  }' | jq

