import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Literal, Optional 

from openai import OpenAI 

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

client = OpenAI(api_key=OPENAI_API_KEY)

app = FastAPI(title="Beam Sandbox Chatbot")


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str 


class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    model: Optional[str] = "gpt-4o-mini"
    temperature: Optional[float] = 0.3


@app.get("/")
def root():
    return {"ok": True, "message": "Beam Sandbox GPT chatbot is running. POST /chat"}


@app.post("/chat")
def chat(req: ChatRequest):
    try:
        # basic safety: ensure at least one user message
        if not req.messages or all(m.role != "user" for m in req.messages):
            raise HTTPException(status_code=400, detail="Provide at least one user message.")

        # Chat Completions API
        resp = client.chat.completions.create(
            model=req.model,
            messages=[m.model_dump() for m in req.messages],
            temperature=req.temperature,
        )
        answer = resp.choices[0].message.content
        return {"reply": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))