import time
from beam import Sandbox, Image, PythonVersion

PORT = 8000

# 1) create a Python 3.11 image; Beam caches images for fast boots
image = Image(python_version=PythonVersion.Python311)

# 2) create sandbox; attach your OPENAI_API_KEY secret so app.py can read it
sandbox = Sandbox(
    image=image,
    cpu=1.0,
    memory="1Gi",
    keep_warm_seconds=1800,     # auto-shutdown after 30 min idle
    secrets=["OPENAI_API_KEY"], # <-- from `beam secret create`
)

print("Launching sandbox...")
sb = sandbox.create()

# 3) upload your app code
sb.fs.upload_file("app.py", "/workspace/app.py")

# 4) install dependencies inside the sandbox
print("Installing dependencies (fastapi, uvicorn, openai)...")
pip_proc = sb.process.exec(
    "python3", "-m", "pip", "install", "--upgrade", "pip", "fastapi", "uvicorn", "openai"
)
for line in pip_proc.logs:
    print(line, end="")
pip_proc.wait()

# 5) start the FastAPI server
print("Starting server...")
server_proc = sb.process.exec(
    "python3", "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", str(PORT),
    cwd="/workspace",
)

# 6) expose the port to the internet (preview URL)
url = sb.expose_port(PORT)
print(f"\nYour chatbot is live at: {url}\n")

# optional: print first few server logs so you know it’s healthy
t0 = time.time()
while time.time() - t0 < 8:
    try:
        line = next(server_proc.logs)
        print(line, end="")
    except StopIteration:
        break

print("\n(keep this process running to keep the sandbox alive)")
